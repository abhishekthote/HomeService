package com.app.services;

import com.app.pojos.Images;

public interface IImageService {

	Images getImage(long serid);

}
