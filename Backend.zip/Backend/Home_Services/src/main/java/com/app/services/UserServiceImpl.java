package com.app.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.app.custom_exception.ResourceNotFoundException;
import com.app.dao.UserRepository;
import com.app.pojos.User;

@Service
@Transactional
public class UserServiceImpl implements IUserService{
	
	@Autowired
	private UserRepository userRepo;
	
	@Override
	public User addNewUser(User user) {
		User newUser=userRepo.save(user);
		return newUser;
	}
	
	@Override
	public User authenticateUser(String email, String pass) {
		Optional<User> optional = userRepo.findByEmailAndPassword(email, pass);
		return optional.orElseThrow(() -> new ResourceNotFoundException("Invalid Credentials"));
	}

	@Override
	public User getUser(long custid) {
		
		return userRepo.findById(custid).orElseThrow(()->new ResourceNotFoundException("Invalid ID"));
	}

	@Override
	public User updateUser(User user, long custid) {
		user.setId(custid);
		userRepo.findById(custid).orElseThrow(()->new ResourceNotFoundException("Invalid ID"));
		return userRepo.save(user);
	}

	@Override
	public User sendPassword(String userName) {
		User oldUser=userRepo.findByEmail(userName).orElseThrow();
		System.out.println("Old user details for forget pwd : "+oldUser);
		return oldUser;
	}
}
