package com.app.services;

//import com.app.pojos.Feedback;
import com.app.pojos.User;

public interface IUserService {
	
	User authenticateUser(String email, String pass);
	User addNewUser(User user);
	User getUser(long custid);
	User updateUser(User user, long custid);
	User sendPassword(String userName);
}
