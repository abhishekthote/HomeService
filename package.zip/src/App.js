import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import Navbar from "./components/navbar";
import Admin from "./pages/admin/admin";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import AvailableServices from "./pages/user/availableservice";
import Signup from "./pages/user/signup";
import Signin from "./pages/user/signin";
import ForgotPassword from "./pages/user/forgotpassword";
import ResetPassword from "./pages/user/resetpassword";
import Service from "./pages/admin/services";
import AddService from "./pages/admin/addservice";
import ServiceList from "./pages/admin/servicelist";
import Home from "./pages/home";
import UpdateService from "./pages/admin/updateservice";
import BookService from "./pages/user/bookservice";
import ShowAllBookedServices from "./pages/admin/showallbookedservices";
import UserDetails from "./pages/user/userdetails";
import ShowProfile from "./pages/user/updateuser";
import UpdateUser from "./pages/user/updateuser";
import UploadImage from "./pages/admin/uploadimage";
import AdminSignin from "./pages/admin/adminsignin";

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/admin" element={<Admin />} />
        <Route path="/home/:id" element={<Home />} />
        <Route path="/home" element={<Home />} />
        <Route path="/available-services" element={<AvailableServices />} />
        <Route path="/signin" element={<Signin />} />
        <Route path="/adminsignin" element={<AdminSignin />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/services" element={<Service />} />
        <Route path="/add-services" element={<AddService />} />
        <Route path="/services-list" element={<ServiceList />} />
        <Route path="/updateservice/:id" element={<UpdateService />} />
        <Route path="/bookservice/:id" element={<BookService/>} />
        <Route path="/showallbookedservices" element={<ShowAllBookedServices />} />
        <Route path="/availableservice/:id" element={<AvailableServices />} />
        <Route path="/userdetails/:id" element={<UserDetails/>}/>
        <Route path="/updateuser/:id" element={<UpdateUser/>}/>
        <Route path="/uploadimage/:id" element={<UploadImage/>}/>
     
      </Routes>
      
      <ToastContainer position="top-right" autoClose={1500} />
    </BrowserRouter>
  );
}

export default App;
