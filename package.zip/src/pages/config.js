const config = {
    serverURL: 'http://localhost:8080/api',
  }
  
  export default config